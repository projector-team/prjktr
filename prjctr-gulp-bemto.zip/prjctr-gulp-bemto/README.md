`npm start` – start project
`npm run build` – build project
