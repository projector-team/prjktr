console.log('asset init.js')
