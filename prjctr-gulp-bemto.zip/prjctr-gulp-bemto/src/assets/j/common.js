console.log('asset common.js')
